clear;
# close all;
# clc;

load data.mat;
node = node(:,1:3);

tooth = figure('name','Tooth');
plotmesh(node,elem);

%% add src and detector
srcdir = [-1 0 0];
srcdir = srcdir/norm(srcdir);
srcpos = [x_mm y_mm/2 z_mm*3/5];
srcparam1 = [1 0 0];
srcdef=struct('srctype','disk',
                'srcpos',srcpos,
                'srcdir',srcdir,
                'srcparam1',srcparam1);            

[node,elem]=mmcaddsrc(node,elem,srcdef);

tooth_src = figure('name','Tooth with source');
plotmesh(node,elem);

detsize = 13;

detpos = [5 y_mm/2-detsize/2 z_mm/2-detsize/2];
detdef =struct('srctype','planar',
              'srcpos',detpos,
              'srcdir',[0 0 0],
              'srcparam1',[0 detsize 0],
              'srcparam2',[0 0 detsize]);
  
[node,elem]=mmcadddet(node,elem,detdef);

tooth_det = figure('name','Tooth with source and detector');
plotmesh(node,elem);

% the created mesh is now in mm
unitinmm = 1;

clear opt face ans srcdir tooth_det triangVolume;


clear cfg srcdir fluence detphoton ncfg seeds;

%% setup and run simulation

% configure the GPU ID!
%cfg.gpuid=1;

cfg.nphoton=1e8;
% could be set lower in many scenarios
% depends on number, dimensions and positioning of detectors 
cfg.maxdetphoton = cfg.nphoton/10;

cfg.node = node;
cfg.elem = elem;

% copy the source-definition from create_mesh.m
cfg.srctype=srcdef.srctype;
cfg.srcpos=srcdef.srcpos;
cfg.srcdir=srcdef.srcdir;
cfg.srcparam1=srcdef.srcparam1;


cfg.detpos=[detpos 1];


% the 5th col of elem contains information about which region the tetrahedron is assigned to 
% this has to be copied to elemprop
% elem has to have 4 cols 
% node has to have 3 cols, the 4th col of node contains similar information as elem-col-5
% used this as reference: https://github.com/fangq/mmc/blob/master/examples/skinvessel/createsession.m
cfg.elemprop=cfg.elem(:,5);
cfg.elem=cfg.elem(:,1:4);

cfg.prop=[0 0 1 1;
          0.1 2.867 0.99 1.63;
          0.35 22.193 0.83 1.49;          
          2.8 0 1 1.333]; %water?!

cfg.tstart=0;
cfg.tend=5e-9;
cfg.tstep=5e-9;
cfg.issaveexit=1;

[flux,detphoton,ncfg,seeds]=mmclab(cfg);

if(isfield(detphoton,'p'))
  p = detphoton.p;
end
if(isfield(detphoton,'v'))
  v = detphoton.v;
end
if(isfield(detphoton,'prop'))
  prop = detphoton.prop;
end

%% visualisation

detw=mmcdetweight(detphoton,prop,1);

binx = 128;
biny = 128;

% detector 2
p = [p(:,2) p(:,3)];
% create a raster/grid
[r_edges, c_edges] = edges_from_nbins(p, [binx biny]);
% sort the photons into the raster/grid
r_idx = lookup (r_edges, p(:,1), "l");
c_idx = lookup (c_edges, p(:,2), "l");
% create empty image
im = zeros(binx, biny);
% sum the calculated weights for each pixel
for j = 1:length(r_idx)
    im(c_idx(j), r_idx(j)) += detw(j);
endfor

im = flip(im);
im = flip(im,2);
figure('name','Detector 2 - NIRT');
imagesc(log(im));
colorbar;
